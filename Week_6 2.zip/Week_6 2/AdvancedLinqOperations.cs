﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Week_6
{
    internal class AdvancedLinqOperations
    {
        // Aggregation Operators
        public static void AggregationDemo()
        {
            List<CashierSales> sales = new List<CashierSales>
            {
                new CashierSales { CashierName = "Ram",  SalesAmount = 15000 },
                new CashierSales { CashierName = "Sita", SalesAmount = 22000 },
                new CashierSales { CashierName = "Hari", SalesAmount = 18000 },
                new CashierSales { CashierName = "Gita", SalesAmount = 25000 }
            };

            int totalCashiers = sales.Count();
            double totalSales = sales.Sum(s => s.SalesAmount);
            double highestSales = sales.Max(s => s.SalesAmount);
            double lowestSales = sales.Min(s => s.SalesAmount);
            double avgSales = sales.Average(s => s.SalesAmount);

            Console.WriteLine("=== Aggregation Operators ===");
            Console.WriteLine("Total number of cashiers: " + totalCashiers);
            Console.WriteLine("Total sales of the day: " + totalSales);
            Console.WriteLine("Highest sales: " + highestSales);
            Console.WriteLine("Lowest sales: " + lowestSales);
            Console.WriteLine("Average sales: " + avgSales);
        }

        // Quantifier Operators (Any/All)
        public static void QuantifierDemo()
        {
            List<Applicant> applicants = new List<Applicant>
            {
                new Applicant { Name = "Aayush", Age = 19 },
                new Applicant { Name = "Bina",   Age = 17 },
                new Applicant { Name = "Chandra",Age = 21 },
                new Applicant { Name = "Dipesh", Age = 16 }
            };

            bool anyUnder18 = applicants.Any(a => a.Age < 18);
            bool allAbove16 = applicants.All(a => a.Age > 16);

            Console.WriteLine("\n=== Quantifier Operators (Any / All) ===");
            Console.WriteLine("Are there any applicants under 18? " + anyUnder18);
            Console.WriteLine("Are all applicants above 16? " + allAbove16);
        }

        // Element Operators
        public static void ElementDemo()
        {
            List<Music> songs = new List<Music>
            {
                new Music { Title = "Song A", DurationSeconds = 180 },  // 3 min
                new Music { Title = "Song B", DurationSeconds = 240 },  // 4 min
                new Music { Title = "Song C", DurationSeconds = 290 },  // 4.5 min
                new Music { Title = "Song D", DurationSeconds = 360 },  // 6 min
            };

            Music firstSong = songs.First();
            Music lastSong = songs.Last();

            Music firstAbove4Min = songs.First(s => s.DurationSeconds > 240); // > 4 min

            Music firstAbove10Min = songs
                .FirstOrDefault(s => s.DurationSeconds > 600); // > 10 min (safe)

            Console.WriteLine("\n=== Element Operators (First / Last / FirstOrDefault) ===");
            Console.WriteLine("First song: " + firstSong.Title);
            Console.WriteLine("Last song: " + lastSong.Title);
            Console.WriteLine("First song with duration > 4 minutes: " + firstAbove4Min.Title);

            if (firstAbove10Min == null)
            {
                Console.WriteLine("No song found with duration > 10 minutes (FirstOrDefault returned null).");
            }
            else
            {
                Console.WriteLine("First song > 10 minutes: " + firstAbove10Min.Title);
            }
        }
    }
}
