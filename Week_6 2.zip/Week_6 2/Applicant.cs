﻿namespace Week_6
{
    internal class Applicant
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
