﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week_6
{
    internal class Calculator
    {
        public delegate int calculator(int a, int b);


        public static int Add(int a, int b) => a + b;

        public static int Sub(int a, int b) => a - b;


        public delegate double DiscountStrategy(double a);

        public static double SeasonalDiscount(double a) => a * 0.1;
        public static double FestivalDiscount(double a) => a * 0.2;

        public static double NoDiscount(double a) => a;


    

    // creating main method to call add and sub
    public void main(String[] args)
        {
            //calculator calc;
            //calc = Add;
            //Console.WriteLine("The Addition of two numbers is: "+calc(20,10));

            //calc = Sub;
            //Console.WriteLine("The subtraction of two numbers is: "+calc(20,10));

            //DiscountStrategy Discount;
            //Discount = SeasonalDiscount;
            //Console.WriteLine("The seasonal discount of rs 10000 is: ", +Discount(10000));

            //Discount = FestivalDiscount;
            //Console.WriteLine("The fetival discount of rs 10000 is: ", +Discount(10000));

            //Discount=NoDiscount;
            //Console.WriteLine("Without any discount the price is: ", Discount(10000));




        }
    }
}
