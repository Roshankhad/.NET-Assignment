﻿namespace Week_6
{
    internal class CashierSales
    {
        public string CashierName { get; set; }
        public double SalesAmount { get; set; }
    }
}
