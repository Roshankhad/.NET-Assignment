﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Week_6
{
    internal class LinqOperations
    {
        // 1. Selection / Projection
        public static void SquareNumbers()
        {
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };

            var squaredNumbers = numbers.Select(n => n * n).ToList();

            Console.WriteLine("Squared Numbers:");
            foreach (var num in squaredNumbers)
            {
                Console.WriteLine(num);
            }
        }

        // 2. Filtering (Where)
        public static void FilterPremiumBooks()
        {
            List<Book> books = new List<Book>
            {
                new Book { Title = "C# Basics", Price = 750 },
                new Book { Title = "Advanced C#", Price = 1500 },
                new Book { Title = "ASP.NET Core", Price = 2200 },
                new Book { Title = "Java Fundamentals", Price = 950 },
                new Book { Title = "Python for AI", Price = 1800 }
            };

            var premiumBooks = books.Where(b => b.Price > 1000).ToList();

            Console.WriteLine("Premium Books (Price > 1000):");
            foreach (var book in premiumBooks)
            {
                Console.WriteLine(book.Title + " - Rs. " + book.Price);
            }
        }

        // 3. Sorting (OrderBy)
        public static void SortStudents()
        {
            List<Student> students = new List<Student>
            {
                new Student { Name = "Ramesh" },
                new Student { Name = "Anita" },
                new Student { Name = "Suman" },
                new Student { Name = "Bikash" },
                new Student { Name = "Nisha" },
                new Student { Name = "Kiran" },
                new Student { Name = "Pooja" },
                new Student { Name = "Aayush" },
                new Student { Name = "Dipesh" },
                new Student { Name = "Laxmi" }
            };

            var sortedStudents = students.OrderBy(s => s.Name).ToList();

            Console.WriteLine("AAA Scholarship Students (Alphabetical Order):");
            foreach (var student in sortedStudents)
            {
                Console.WriteLine(student.Name);
            }
        }
    }
}
