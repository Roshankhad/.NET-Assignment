﻿namespace Week_6
{
    internal class Music
    {
        public string Title { get; set; }
        public int DurationSeconds { get; set; }  // duration in seconds
    }
}
