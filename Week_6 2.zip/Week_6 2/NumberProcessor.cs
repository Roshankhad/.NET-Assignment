﻿using System;

namespace Week_6
{
    internal class NumberProcessor
    {
        // Method that accepts array and Func delegate condition
        public static void ProcessNumbers(int[] numbers, Func<int, bool> condition)
        {
            foreach (int number in numbers)
            {
                if (condition(number))
                {
                    Console.WriteLine(number);
                }
            }
        }
    }
}
