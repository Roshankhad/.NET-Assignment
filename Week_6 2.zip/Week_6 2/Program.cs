﻿using static Week_6.Calculator;

namespace Week_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Arithmetic Delegates
            Console.WriteLine("=====Task 1====");
            calculator calc;
            calc = Add;
            Console.WriteLine("The Addition of two numbers is: " + calc(20, 10));

            calc = Sub;
            Console.WriteLine("The subtraction of two numbers is: " + calc(20, 10));

            //Discount Delegates
            DiscountStrategy Discount;
            Discount = SeasonalDiscount;
            Console.WriteLine("The seasonal discount of rs 10000 is: " +Discount(10000));

            Discount = FestivalDiscount;
            Console.WriteLine("The fetival discount of rs 10000 is: " +Discount(10000));

            Discount = NoDiscount;
            Console.WriteLine("Without any discount the price is: " +Discount(10000));

            Console.WriteLine("=====Task 2=====");
            // calling with predefined methods
            double price = 10000;

            double d1 = CalculateFinalPrice(price, Calculator.SeasonalDiscount);
            Console.WriteLine("Final price after Seasonal Discount: " + (price - d1));

            double d2 = CalculateFinalPrice(price, Calculator.FestivalDiscount);
            Console.WriteLine("Final price after Festival Discount: " + (price - d2));

            double d3 = CalculateFinalPrice(price, Calculator.NoDiscount);
            Console.WriteLine("Final price without any Discount: " + (price - d3));

            //calling with lamda expression which accepts 30% discount
            double d4 = CalculateFinalPrice(price, p => p * 0.30);
            Console.WriteLine("Final price after 30% Lambda Discount: " + (price - d4));

            Console.WriteLine("=====Task 3=====");

            int[] nums = { 3, 4, 7, 10, 11, 12, 18, 25 };

            Console.WriteLine("=== Even Numbers ===");
            // Calling using lambda for even numbers
            NumberProcessor.ProcessNumbers(nums, n => n % 2 == 0);

            Console.WriteLine("=== Numbers Greater Than 10 ===");
            // Calling using lambda for numbers > 10
            NumberProcessor.ProcessNumbers(nums, n => n > 10);

            Console.WriteLine("=====Task 4=====");
            Console.WriteLine("=== Selection / Projection ===");
            LinqOperations.SquareNumbers();

            Console.WriteLine("\n=== Filtering (Where) ===");
            LinqOperations.FilterPremiumBooks();

            Console.WriteLine("\n=== Sorting (OrderBy) ===");
            LinqOperations.SortStudents();

            Console.WriteLine("=====Task 5=====");
            AdvancedLinqOperations.AggregationDemo();
            AdvancedLinqOperations.QuantifierDemo();
            AdvancedLinqOperations.ElementDemo();

            Console.WriteLine("=====Task 6=====");
            TourReport.GenerateMarketAnalysisReport();

        }



        public static double CalculateFinalPrice(double OriginalPrice, DiscountStrategy strategy)
        {
            return strategy(OriginalPrice);
        }
    }
}
