﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Formats.Asn1;
using System.Text;

namespace Week_6
{
    public class Rectangle
    {
        private double length;
        private double breadth;


        public double Length

            {
            get => length; 
            set => length = value;
        }

        public double Breadth
        {
            get => breadth;
            set => breadth = value;
        }

        public double Area() => length * breadth;

        public string ShowDetails() => $"Length: {length}, Breadth: {breadth}";

    }
}
