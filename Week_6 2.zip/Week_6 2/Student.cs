﻿namespace Week_6
{
    internal class Student
    {
        public string Name { get; set; }
    }
}
