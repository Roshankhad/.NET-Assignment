﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Week_6
{
    internal class TourReport
    {
        public static void GenerateMarketAnalysisReport()
        {
            // Sample data
            List<TourBooking> bookings = new List<TourBooking>
            {
                new TourBooking { CustomerName = "Ramesh", Destination = "Pokhara",      Price = 8000,  DurationInDays = 3, IsInternational = false },
                new TourBooking { CustomerName = "Sita",   Destination = "Bangkok",      Price = 25000, DurationInDays = 5, IsInternational = true  },
                new TourBooking { CustomerName = "Hari",   Destination = "Chitwan",      Price = 12000, DurationInDays = 4, IsInternational = false },
                new TourBooking { CustomerName = "Gita",   Destination = "Dubai",        Price = 45000, DurationInDays = 6, IsInternational = true  },
                new TourBooking { CustomerName = "Kiran",  Destination = "Lumbini",      Price = 15000, DurationInDays = 5, IsInternational = false },
                new TourBooking { CustomerName = "Nisha",  Destination = "Singapore",    Price = 42000, DurationInDays = 4, IsInternational = true  },
            };

            // 1. Filter: price > 10,000 AND duration > 4 days
            var filtered = bookings
                .Where(b => b.Price > 10000 && b.DurationInDays > 4);

            // 2. Sort: Domestic first (IsInternational == false), then International,
            //    then by Price (ascending)
            var sorted = filtered
                .OrderBy(b => b.IsInternational)   // false (Domestic) comes before true
                .ThenBy(b => b.Price);

            // 3. Project (transform) into TourSummary list
            var summaries = sorted
                .Select(b => new TourSummary
                {
                    CustomerName = b.CustomerName,
                    Destination = b.Destination,
                    Category = b.IsInternational ? "International" : "Domestic"
                })
                .ToList();

            // 4. Display result in clean format
            Console.WriteLine("=== Tour Market Analysis Report ===\n");

            foreach (var s in summaries)
            {
                Console.WriteLine($"Customer   : {s.CustomerName}");
                Console.WriteLine($"Destination: {s.Destination}");
                Console.WriteLine($"Category   : {s.Category}");
                Console.WriteLine(new string('-', 40));
            }
        }
    }
}
