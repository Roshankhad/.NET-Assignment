﻿namespace Week_6
{
    internal class TourSummary
    {
        public string CustomerName { get; set; }
        public string Destination { get; set; }
        public string Category { get; set; }   // "International" or "Domestic"
    }
}
